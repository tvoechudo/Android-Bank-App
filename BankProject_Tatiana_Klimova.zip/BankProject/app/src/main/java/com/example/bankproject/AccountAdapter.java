package com.example.bankproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AccountAdapter extends BaseAdapter {
    ArrayList<Account> acList = new ArrayList<>();
    LayoutInflater inflater;

    public AccountAdapter(Context context, ArrayList<Account> acList){
        this.acList = acList;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return acList.size();
    }

    @Override
    public Object getItem(int position) {
        return acList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null){
            convertView = inflater.inflate(R.layout.list_row, null);
            holder = new ViewHolder();
            holder.image = convertView.findViewById(R.id.imgAccount);
            holder.number = convertView.findViewById(R.id.txvAccNo);
            holder.balance = convertView.findViewById(R.id.txvBalance);
            convertView.setTag(holder);
        }
        else {
            holder = (ViewHolder) convertView.getTag();
        }
        holder.image.setImageResource(acList.get(position).getImg());
        holder.number.setText(String.valueOf(acList.get(position).getAccountNumber()));
        holder.balance.setText("$ " + String.valueOf(acList.get(position).getBalance()));
        return convertView;
    }


    static class ViewHolder{
        ImageView image;
        TextView number;
        TextView balance;
    }
}
