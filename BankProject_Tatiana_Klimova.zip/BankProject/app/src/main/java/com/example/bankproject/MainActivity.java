package com.example.bankproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    TextView cardNumber, pin;
    Button login;
    ArrayList<Client> clients = new ArrayList<>();
    public static Client clientObj;
    public static ArrayList<Account> allAccounts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardNumber = findViewById(R.id.etxCardNumber);
        pin = findViewById(R.id.etxPin);
        login = findViewById(R.id.btnLogin);

        fillData();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cardInput = cardNumber.getText().toString();
                String pinInput = pin.getText().toString();
                Client clientInput = clientExists(cardInput, pinInput);
                if (clientInput != null){
                    clientObj = clientInput;
                    Intent intent = new Intent(getBaseContext(), ClientActivity.class);
                    startActivity(intent);
                    cardNumber.setText("");
                    pin.setText("");
                }
                else{
                    Toast.makeText(getBaseContext(),"No such client", Toast.LENGTH_SHORT).show();
                }
            }
        });
        
    }

    public void fillData(){
        clients.add(new Client("12345678", "1234", "Harry", "Potter", "4 Privet Drive", "HarryPotter@hogwarts.com" ));
        clients.add(new Client("12341234", "0001", "Hermione", "Granger", "16 Heathgate", "HermioneGranger@hogwarts.com" ));
        clients.add(new Client("90909090", "9999", "Ron", "Weasley", "1 Burrow", "RonWeasley@hogwarts.com" ));

        Account acc1 = new Account(10001, "Saving", 4000.00);
        Account acc2 = new Account(10002, "Checking", 500.00);
        Account acc3 = new Account(10003, "Checking", 700.00);
        Account acc4 = new Account(10004, "Saving", 1500.00);
        Account acc5 = new Account(10005, "Saving", 1100.00);
        Account acc6 = new Account(10006, "Checking", 800.00);

        clients.get(0).addAccount(acc1);
        clients.get(0).addAccount(acc2);
        clients.get(1).addAccount(acc3);
        clients.get(1).addAccount(acc4);
        clients.get(1).addAccount(acc5);
        clients.get(2).addAccount(acc6);

        allAccounts.add(acc1);
        allAccounts.add(acc2);
        allAccounts.add(acc3);
        allAccounts.add(acc4);
        allAccounts.add(acc5);
        allAccounts.add(acc6);
    }

    public Client clientExists(String cardNo, String pin) {
        for (Client client : clients) {
            if (client.getAccessNumber().equals(cardNo) && client.getPinCode().equals(pin)) {
                return client;
            }
        }
        return null;
    }


}