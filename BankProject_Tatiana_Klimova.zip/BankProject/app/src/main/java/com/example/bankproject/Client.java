package com.example.bankproject;

import java.util.ArrayList;

public class Client {

    String accessNumber;
    String pinCode;
    String firstName;
    String lastName;
    ArrayList<Account> accountsList = new ArrayList<>();
    String address;
    String email;
    ArrayList<String> billersList = new ArrayList<>();

    public Client(String accessNumber, String pinCode, String firstName, String lastName, String address, String email) {
        this.accessNumber = accessNumber;
        this.pinCode = pinCode;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.email = email;
    }

    public String getAccessNumber() {
        return accessNumber;
    }

    public String getPinCode() {
        return pinCode;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public ArrayList<Account> getAccountsList() {
        return accountsList;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {return email; }

    public ArrayList<String> getBillersList() {return billersList; }

    public void addAccount(Account account){
        this.accountsList.add(account);
    }

    public void addBiller(String number){
        this.billersList.add(number);
    }
}
