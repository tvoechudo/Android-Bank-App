package com.example.bankproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AccountActivity extends AppCompatActivity {
    TextView accNumber, accType, accBalance;
    ImageView imgAccType;
    ImageButton payBills, transferMoney, back, logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        accNumber = findViewById(R.id.txvAccNumber);
        accType = findViewById(R.id.txvAcctype);
        accBalance = findViewById(R.id.txvAccBalance);
        imgAccType = findViewById(R.id.imgAccType);
        payBills = findViewById(R.id.btnBills);
        transferMoney = findViewById(R.id.btnTransfer);
        back = findViewById(R.id.btnBack);
        logout = findViewById(R.id.btnOut);

        Client currentClient = MainActivity.clientObj;
        Account currentAccount = ClientActivity.accountObj;
        String balanceString = "$ " + Double.toString(currentAccount.getBalance());

        accNumber.setText(String.valueOf(currentAccount.getAccountNumber()));
        accType.setText(currentAccount.getAccountType());
        accBalance.setText(balanceString);
        imgAccType.setImageResource(currentAccount.getImg());



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), ClientActivity.class);
                startActivity(intent);
            }
        });

        payBills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), BillsActivity.class);
                startActivity(intent);
            }
        });

        transferMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), TransferActivity.class);
                startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                MainActivity.clientObj = null;
            }
        });
    }
}