package com.example.bankproject;

public class Account {

    int accountNumber;
    String accountType;
    double balance;
    int img;

    public Account(int accountNumber, String accountType, double balance) {
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public double getBalance() {
        return balance;
    }

    public int getImg(){
        if (accountType.equals("Saving"))
            return R.mipmap.save;
        else
            return R.mipmap.check;
    }

    public void pay(Double amount){
        balance -= amount;
    }

    public void addMoney(Double amount){
        this.balance += amount;
    }

    public void transfer(Double amount, Account account){
        this.balance -= amount;
        account.addMoney(amount);
    }
}
