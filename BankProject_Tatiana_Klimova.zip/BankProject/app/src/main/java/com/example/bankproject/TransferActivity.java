package com.example.bankproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class TransferActivity extends AppCompatActivity {

    TextView accNumber, accBalance, name, otherAccNo, amount, taxes;
    Spinner myAccounts;
    RadioButton toMyAcc, toOtherClient;
    ImageButton back, out;
    Button transfer;
    ArrayList<Account> myAccList = (ArrayList)MainActivity.clientObj.getAccountsList().clone();
    ArrayList<Integer> myAccNumbers = new ArrayList<>();
    RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer);

        if(myAccList.size() > 1) {
            myAccList.remove(ClientActivity.accountObj);
            for (Account account : myAccList) {
                myAccNumbers.add(account.getAccountNumber());
            }
        }

        accNumber = findViewById(R.id.txvAccNoTransfer);
        accBalance = findViewById(R.id.txvBalanceTransfer);
        name = findViewById(R.id.etxTransferName);
        otherAccNo = findViewById(R.id.etxTransferAccount);
        amount = findViewById(R.id.etxTransferAmount);
        taxes = findViewById(R.id.txvTaxes);
        myAccounts = findViewById(R.id.spAccounts);
        toMyAcc = findViewById(R.id.rbMyAccount);
        toOtherClient = findViewById(R.id.rbOtherAccount);
        back = findViewById(R.id.btnTransferBack);
        out = findViewById(R.id.btnTransferOut);
        transfer = findViewById(R.id.btnTransferMoney);
        radioGroup = findViewById(R.id.radioGroup);

        accNumber.setText(String.valueOf(ClientActivity.accountObj.getAccountNumber()));
        accBalance.setText("$ " + String.valueOf(ClientActivity.accountObj.getBalance()));

        toOtherClient.setChecked(true);
        ArrayAdapter aa = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, myAccNumbers);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                View radioButton = radioGroup.findViewById(checkedId);
                int index = radioGroup.indexOfChild(radioButton);

                switch (index) {
                    case 0:
                        if (myAccNumbers.size() > 0) {
                            name.setEnabled(false);
                            otherAccNo.setEnabled(false);
                            name.setText("My Account");
                            myAccounts.setAdapter(aa);
                            taxes.setText("0.0");
                        } else {
                            Toast.makeText(getBaseContext(), "You don't have other accounts", Toast.LENGTH_SHORT).show();
                            toOtherClient.toggle();
                        }
                        break;
                    case 1:
                        myAccounts.setAdapter(null);
                        name.setEnabled(true);
                        otherAccNo.setEnabled(true);
                        name.setText("");
                        otherAccNo.setText("");
                        break;
                }
            }
        });

        amount.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (toOtherClient.isChecked()) {
                    if(!amount.getText().toString().isEmpty()){
                        taxes.setText(String.valueOf(Double.parseDouble(amount.getText().toString()) * 0.01));
                    }
                    else{
                        taxes.setText("0.0");
                    }
                }
                if(toMyAcc.isChecked()){
                    taxes.setText("0.0");
                }
            }
        });


        myAccounts.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                otherAccNo.setText(String.valueOf(myAccNumbers.get(position)));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        transfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (amount.getText().toString().isEmpty() || name.getText().toString().isEmpty() || otherAccNo.getText().toString().isEmpty()) {
                    Toast.makeText(getBaseContext(), "Empty Input", Toast.LENGTH_SHORT).show();
                } else if (Double.parseDouble(amount.getText().toString())+Double.parseDouble(taxes.getText().toString()) > ClientActivity.accountObj.getBalance()) {
                    Toast.makeText(getBaseContext(), "Insufficient fund", Toast.LENGTH_SHORT).show();
                } else {
                    Account accForTransfer = getAccountById(Integer.parseInt(otherAccNo.getText().toString()));
                    if (accForTransfer != null){
                        ClientActivity.accountObj.transfer(Double.parseDouble(amount.getText().toString()), accForTransfer);
                        Toast.makeText(getBaseContext(), "You have transferred $" + amount.getText().toString(), Toast.LENGTH_SHORT).show();
                        amount.setText("");
                        name.setText("");
                        otherAccNo.setText("");
                        accBalance.setText("$ " + String.valueOf(ClientActivity.accountObj.getBalance()));
                    }
                    else{
                        Toast.makeText(getBaseContext(), "No such account", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                MainActivity.clientObj = null;
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), AccountActivity.class);
                startActivity(intent);
            }
        });

    }

    public Account getAccountById (int id){
        for (Account account: MainActivity.allAccounts){
            if(account.getAccountNumber() == id){
                return account;
            }
        }
        return null;
    }
}