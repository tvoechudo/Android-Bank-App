package com.example.bankproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.example.bankproject.R.layout.activity_client;

public class ClientActivity extends AppCompatActivity {
    TextView name, address, email;
    ListView accounts;
    public static ArrayList<Account> acList = MainActivity.clientObj.getAccountsList();
    public static Account accountObj;
    ImageButton logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_client);

        name = findViewById(R.id.txvName);
        address = findViewById(R.id.txvAddress);
        email = findViewById(R.id.txvEmail);
        accounts = findViewById(R.id.lvAccounts);
        logout = findViewById(R.id.btnLogout);

        String fullName = MainActivity.clientObj.getFirstName() + " " + MainActivity.clientObj.getLastName();
        name.setText(fullName);
        address.setText(MainActivity.clientObj.getAddress());
        email.setText(MainActivity.clientObj.getEmail());

        accounts.setAdapter(new AccountAdapter(this, acList));
        accounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getBaseContext(), AccountActivity.class);
                startActivity(intent);
                accountObj = acList.get(position);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                MainActivity.clientObj = null;
            }
        });
    }


}