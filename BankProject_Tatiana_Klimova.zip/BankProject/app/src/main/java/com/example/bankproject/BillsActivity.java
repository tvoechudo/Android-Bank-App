package com.example.bankproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class BillsActivity extends AppCompatActivity {

    TextView accNumber, accBalance, billNumber, amount;
    Spinner utilities, savedNumbers;
    CheckBox selectSaved;
    Button pay, save;
    ImageButton back, out;
    String[] utils = {"Hydro", "Water", "Gas", "Phone"};
    int[] images = {R.mipmap.hydro, R.mipmap.water, R.mipmap.heat, R.mipmap.phone};
    ImageView imadeUtils;
    ArrayList<String> savedBillers = MainActivity.clientObj.getBillersList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bills);

        accNumber = findViewById(R.id.txvAccNoBills);
        accBalance = findViewById(R.id.txvAccBalanceBills);
        billNumber = findViewById(R.id.etxBillNumber);
        amount = findViewById(R.id.etxAmount);
        utilities = findViewById(R.id.spUtilities);
        savedNumbers = findViewById(R.id.spSubscriptions);
        selectSaved = findViewById(R.id.chbxSelectSaved);
        pay = findViewById(R.id.btnPayBill);
        save = findViewById(R.id.btnSaveBill);
        back = findViewById(R.id.btnBillsBack);
        out = findViewById(R.id.btnBillsOut);
        imadeUtils = findViewById(R.id.imgUtils);

        accNumber.setText(String.valueOf(ClientActivity.accountObj.getAccountNumber()));
        accBalance.setText("$ " + String.valueOf(ClientActivity.accountObj.getBalance()));

        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);
                MainActivity.clientObj = null;
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), AccountActivity.class);
                startActivity(intent);
            }
        });

        ArrayAdapter aa = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, utils);
        utilities.setAdapter(aa);

        utilities.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                imadeUtils.setImageResource(images[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ArrayAdapter aa1 = new ArrayAdapter(this, R.layout.support_simple_spinner_dropdown_item, savedBillers);

        selectSaved.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    if (savedBillers.size() > 0) {
                        billNumber.setEnabled(false);
                        savedNumbers.setAdapter(aa1);
                        savedNumbers.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                billNumber.setText(savedBillers.get(position));
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });
                    } else {
                        Toast.makeText(getBaseContext(), "the list of saved prescriptions is empty", Toast.LENGTH_SHORT).show();
                        selectSaved.toggle();
                    }
                } else {
                    billNumber.setEnabled(true);
                    savedNumbers.setAdapter(null);
                }
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectSaved.isChecked())
                    Toast.makeText(getBaseContext(), "Nothing to save", Toast.LENGTH_SHORT).show();
                else{
                    String newBill = billNumber.getText().toString();
                    MainActivity.clientObj.addBiller(newBill);
                    Toast.makeText(getBaseContext(), "Saved", Toast.LENGTH_SHORT).show();
                }
            }
        });

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(billNumber.getText().toString().isEmpty() || amount.getText().toString().isEmpty())
                    Toast.makeText(getBaseContext(), "Empty input", Toast.LENGTH_SHORT).show();
                else {
                    Double amountInput = Double.parseDouble(amount.getText().toString());
                    if (amountInput > ClientActivity.accountObj.getBalance()) {
                        Toast.makeText(getBaseContext(), "Insufficient fund", Toast.LENGTH_SHORT).show();
                    } else {
                        ClientActivity.accountObj.pay(amountInput);
                        Toast.makeText(getBaseContext(), "The bill has been paid", Toast.LENGTH_SHORT).show();
                        accBalance.setText("$ " + String.valueOf(ClientActivity.accountObj.getBalance()));
                        billNumber.setText("");
                        amount.setText("");
                    }
                }
            }
        });
    }

    public void buttonAction (Button btn){

    }
}


